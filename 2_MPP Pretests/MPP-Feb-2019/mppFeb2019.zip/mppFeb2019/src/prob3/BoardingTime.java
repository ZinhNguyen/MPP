package prob3;

public interface BoardingTime {

}
