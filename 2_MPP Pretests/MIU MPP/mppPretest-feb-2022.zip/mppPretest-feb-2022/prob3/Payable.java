package prob3;

//implement
public interface Payable {
	double getSalary();
}
