package prob2;

public class MyStringStack {
	private Node top;
	
	//Pushes the string s onto the stack -- the top
	//Node is populated with this input String
	//If the input String is null, it is ignored
	public void push(String s) {
		//implement
	}
	
	//Pops the stack -- the value stored in the top 
	//Node is returned. If the stack is empty
	//when pop() is called, pop() returns null.
	public String pop() {
		//implement
		return null;
	}
	
	//DO NOT MODIFY
	//Returns a space-separated string consisting
	//of the elements of this stack
	public String toString() {
		return Util.toString(this);
	}

	//DO NOT MODIFY
	private class Node {
		private String value;
		private Node next;
	}
}
